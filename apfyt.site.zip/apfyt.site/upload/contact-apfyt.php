<!doctype html>
<html>
<head>
<script src="https://use.fontawesome.com/ded1749783.js"></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Contact - Josh Payne</title>
	<link rel="stylesheet" href="css/style-apfyt.css" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
	<script src="js/mobile.js" type="text/javascript"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script> $(window).load(function() {
		$(".se-pre-con").fadeOut("slow");;
	});
	</script>
</head>
<body>
<div class="se-pre-con">



</div>
	<div id="page">
		<div id="header">
			<div id="contact">
				
				<ul id="navigation">
					<li class="selected">
                        <a href="contact-apfyt.html">| Contact |</a>
                    </li>
                    <li>
                        <a href="about-apfyt.html">About</a>
                    </li>
                    <li>
                        <a href="index-apfyt.html">Home</a>
                    </li>
					
				</ul>
			</div>
		</div>
        <div id="login-createAccount">
                <div>
                <ul>
                    <li class="login" id="login"> 
                        <a href="login-apfyt.html">Log in</a>
                        </li>
                        <li class="signup">
                        <a href="createaccount-apfyt.html">Sign up</a>
                        </li>
                </ul>

            </div>
        </div>
		<div id="body" class="contact">
			<div class="header">
				<div class="contact">
					<h1>A penny for your thoughts</h1>
					<h2>Want to get in touch? We'd love to hear from you!</h2>
					
				</div>
			</div>
		</div>

		<section id="contactsheet">
        <div class="container">
         
         <form name="sentMessage" id="contactForm" novalidate>
        <div class="form-group col-xs-8 floating-label-form-group controls">
        	<i class="fa fa-user" aria-hidden="true"></i>
			<input type="text" class="form-control" placeholder="Name" id="name" required data-validation-required-message="Please enter your name.">
			
				<p class="help-block text-danger"></p>
			<i class="fa fa-envelope" aria-hidden="true"></i>	
			<input type="email" class="form-control" placeholder="Email Address" id="email" required data-validation-required-message="Please enter your email address.">
				
				<p class="help-block text-danger"></p>
			<i class="fa fa-info" aria-hidden="true"></i>
			<input type="subject" class="form-control" placeholder="Subject" id="message" required data-validation-required-message="Please enter the subject.">
                
                <p class="help-block text-danger"></p>
             <i class="fa fa-comment" aria-hidden="true"></i>  
             <textarea rows="5" class="form-control" placeholder="Message" id="message" required data-validation-required-message="Please enter a message."></textarea>
               
                <p class="help-block text-danger"></p>
                <br>
                <div class="row">
                            <div class="form-group col-xs-12">
                                <button type="submit" class="btn btn-success btn-lg">Send</button>
                            </div>
                        </div>
                    </form>
                </div>



    </section>
    
			<div class="footnote">
            <footer class="text-center">
        <div class="footer-above">
            <div class="container">
                <div class="row">
                    <div class="footer-col col-md-4">
                       
                       
                    </div>
                    <div class="footer-col col-md-4">
                        
                        <ul class="list-inline">
                            <li>
                                <a href="https://www.facebook.com/profile.php?id=100006801288911" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i> </a>
                            </li>
                            
                            <li>
                                <a href="https://twitter.com/@fouroclockfive" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/fouroclockfive/" class="btn-social btn-outline"><i class="fa fa-fw fa-google"></i></a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/in/josh-payne-4b30184b?trk=nav_responsive_tab_profile_pic" class="btn-social btn-outline"><i class="fa fa-fw fa-apple"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="footer-col col-md-4">
                        
                        
                    </div>
                </div>
                <h6>&copy; 2017 APFYT INC. & JOSH PAYNE | ALL RIGHTS RESERVED</h6>
            </div>

        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript" src="http://arrow.scrolltotop.com/arrow38.js"></script>
	
	    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/freelancer.min.js"></script>

</body>
</html>