<?php
	define("TITLE", "A Penny For Your Thoughts");
	$name = $_POST['name'];
	$visitor_email = $_POST['email'];
	$message = $_POST['message'];
	$email_from = 'yourname@yourwebsite.com';
    $email_subject = "New Form submission";
    $email_body = "You have received a new message from the user $name.\n".
                            "Here is the message:\n $message".
  $to = "snare117@gmail.com";
  $headers = "From: $email_from \r\n";
  $headers .= "Reply-To: $visitor_email \r\n";
  mail($to,$email_subject,$email_body,$headers);



?>
	<div id="contact">
		<hr>

		<h1>Want to get in touch? We'd love to hear from you!</h1>
		
		<form method="post" action="" id="contact-form">

		<label for="name">Name</label>
		<input type="text" id="name" name="name">

		<label for="company">Company</label>
		<input type="text" id="company" name="company">

		<label for="email">Email Address</label>
		<input type="email" id="email" name="email">

		<label for="message">Message</label>
		<textarea id="message" name="message">

		<input type="chackbox" id="subscribe" name="subscribe" value="subscribe">
		<label for="subscribe">Stay updated</label>

		<input type="submit" class="button next" name="contact-submit" value="Send Message">

		</form>


<?php include('includes/footer.php'); ?>